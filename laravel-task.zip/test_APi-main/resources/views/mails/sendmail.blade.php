<html>
    <head>
        <title>{{ env('APP_NAME')}}</title>
    </head>
    <body>
        <h1>{{ $title }}</h1>
        <p>{!! $body !!}</p>
    </body>

</html>